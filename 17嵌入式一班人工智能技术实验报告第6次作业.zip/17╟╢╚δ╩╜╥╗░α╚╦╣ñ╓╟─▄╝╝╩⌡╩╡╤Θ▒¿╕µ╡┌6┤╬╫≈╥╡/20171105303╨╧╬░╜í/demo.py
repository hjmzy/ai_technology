print("20171105303")
print("XWJ")
print("Hello World!!")
input()
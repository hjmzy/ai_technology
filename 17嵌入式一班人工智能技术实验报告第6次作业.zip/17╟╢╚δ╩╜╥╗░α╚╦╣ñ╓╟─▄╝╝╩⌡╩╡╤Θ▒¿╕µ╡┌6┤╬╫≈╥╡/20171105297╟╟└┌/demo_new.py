print("I Love Study") #2
print("20171105297")  #0
print("QL")           #1
input()               #3

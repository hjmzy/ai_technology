print("20171105297")
print("QL")
print("I Love Study")
input()
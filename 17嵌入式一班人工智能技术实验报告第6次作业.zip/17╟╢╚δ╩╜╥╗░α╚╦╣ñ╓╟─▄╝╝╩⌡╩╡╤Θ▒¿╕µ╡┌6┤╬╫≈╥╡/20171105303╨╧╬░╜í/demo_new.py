input()                #3
print("20171105303")   #0
print("Hello World!!") #2
print("XWJ")           #1

print("hahaha")         #2
print("20171105265")    #0
input()                 #3
print("this is a demo") #1

lllllll #0
yyyyyyy #1
sssssss #2

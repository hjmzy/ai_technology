print("20171105301")
print("ZJL")
print("I have many friends!!")
input()
print("I have many friends!!") #2
input()                        #3
print("20171105301")           #0
print("ZJL")                   #1
